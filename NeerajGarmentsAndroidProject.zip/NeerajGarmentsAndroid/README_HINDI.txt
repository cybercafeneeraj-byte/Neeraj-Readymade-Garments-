NEERAJ READYMDE GARMENTS — ANDROID APP PROJECT

इस ZIP में Android Studio में APK बनाने योग्य प्रोजेक्ट और ऑफलाइन ऐप की HTML फ़ाइल है। यह APK फ़ाइल नहीं है। इस वातावरण में Android SDK/Gradle और इंटरनेट उपलब्ध न होने के कारण यहाँ APK compile नहीं हो पाया।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में इस ZIP को extract करके NeerajGarments फ़ोल्डर Open करें।
3. इंटरनेट चालू रखें ताकि Gradle/Android SDK डाउनलोड हो सकें। compileSdk 35 इंस्टॉल/स्वीकार करें।
4. Gradle Sync पूरा होने दें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK सामान्यतः app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

ऐप की विशेषताएँ (मौजूदा prototype के अनुसार):
- उत्पाद, फोटो, साइज/रंग (तैयार विकल्प और मैन्युअल), मात्रा/स्टॉक
- ग्राहक का नाम/फोन, बिक्री, बिल, भुगतान/उधारी
- खर्च, रिपोर्ट और स्थानीय नियम-आधारित व्यवसाय सारांश
- WhatsApp पर बिल साझा करने का प्रयास, Android print dialog, JSON backup/restore

महत्वपूर्ण सीमाएँ:
- डेटा इसी मोबाइल के ऐप में स्थानीय रूप से सेव होगा; cloud sync नहीं है।
- यह शुरुआती संस्करण है; पहली बार इस्तेमाल से पहले नकली रिकॉर्ड से बिक्री/स्टॉक/प्रिंट/WhatsApp का परीक्षण करें।
- अपडेट/अनइंस्टॉल करने से पहले JSON बैकअप लें।
- वास्तविक ऑनलाइन AI, GST-compliant invoice, multi-device sync शामिल नहीं हैं।
